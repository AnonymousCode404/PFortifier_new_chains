<?php
// @deprecated 3.5.0 Backward compatibility with 2.x, 3.0.x
class_alias('Cake\Mailer\AbstractTransport', 'Cake\Network\Email\AbstractTransport');
deprecationWarning('Use Cake\Mailer\AbstractTransport instead of Cake\Network\Email\AbstractTransport.');
