<?php
// @deprecated 3.4.0 Load new class and alias.
class_exists('Cake\Http\Client\Response');
deprecationWarning('Use Cake\Http\Client\Response instead of Cake\Network\Http\Response.');
