<?php
// @deprecated 3.4.0 Load new class and alias.
class_exists('Cake\Http\Client\Auth\Basic');
deprecationWarning('Use Cake\Http\Client\Auth\Basic instead of Cake\Network\Http\Auth\Basic.');
