<?php
// @deprecated 3.6.0 Backward compatibility alias
class_alias('Cake\Http\Exception\UnauthorizedException', 'Cake\Network\Exception\UnauthorizedException');
deprecationWarning('Use Cake\Http\Exception\UnauthorizedException instead of Cake\Network\Exception\UnauthorizedException.');
