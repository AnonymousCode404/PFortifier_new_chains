<?php
// @deprecated 3.6.0 Backward compatibility alias
class_alias('Cake\Http\Exception\BadRequestException', 'Cake\Network\Exception\BadRequestException');
deprecationWarning('Use Cake\Http\Exception\BadRequestException instead of Cake\Network\Exception\BadRequestException.');
