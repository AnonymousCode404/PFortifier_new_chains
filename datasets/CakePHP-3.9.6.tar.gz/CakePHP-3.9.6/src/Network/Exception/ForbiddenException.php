<?php
// @deprecated 3.6.0 Backward compatibility alias
class_alias('Cake\Http\Exception\ForbiddenException', 'Cake\Network\Exception\ForbiddenException');
deprecationWarning('Use Cake\Http\Exception\ForbiddenException instead of Cake\Network\Exception\ForbiddenException.');
