<?php

/**
 * Kettle Include File
 *
 * Allows you to hook into the Kettle helper application by bootstrapping
 * any additional runtime requirements, configurations or routes.
 *
 * The main Kettle $app object is accessible in this file.
 */

