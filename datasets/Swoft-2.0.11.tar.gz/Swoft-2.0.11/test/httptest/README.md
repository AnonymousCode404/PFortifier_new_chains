# Http tests

**If you want to run these tests, you must start the http server.**

## Config

Please see http-client.env.json

## Start server

```bash
php bin/swoft http:start
```

## Run

Can only be run inside phpstorm 
