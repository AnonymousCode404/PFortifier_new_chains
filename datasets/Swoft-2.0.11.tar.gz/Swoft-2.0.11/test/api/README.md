# Http tests

**If you want to run these tests, you must start the http server.**

## Start server

```bash
php bin/swoft http:start
```
